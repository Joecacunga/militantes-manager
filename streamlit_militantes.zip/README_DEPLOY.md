
# Militantes Manager - Streamlit (Protótipo)

Este repositório contém um protótipo de **Web App** em Streamlit para gerir registos de militantes por CAP,
com funcionalidades de importação (Excel, DOCX, clipboard), deteção de duplicados (telefone, CAP, nomes fuzzy)
e exportação de ficheiros limpos e relatórios.

## Como executar localmente (para testar)

1. Criar um ambiente virtual (recomendado):
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux/Mac
   venv\Scripts\activate    # Windows
   ```
2. Instalar dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Executar a app:
   ```bash
   streamlit run app.py
   ```

## Deploy (Streamlit Community Cloud)

1. Criar um repositório no GitHub com estes ficheiros (app.py, requirements.txt).
2. Ir a https://streamlit.io/cloud e conectar o repositório.
3. Escolher a branch e clicar em deploy. A app ficará disponível via URL pública.

