
import streamlit as st
import pandas as pd, re, json, io
from pathlib import Path
from rapidfuzz import fuzz, process
from difflib import SequenceMatcher

st.set_page_config(page_title="Militantes Manager (Web)", layout="wide")

def normalize_phone(p):
    if pd.isna(p) or p is None:
        return ""
    s = re.sub(r'[^0-9]', '', str(p))
    return s.lstrip('0')

def normalize_name(n):
    if pd.isna(n) or n is None:
        return ""
    s = str(n).strip()
    s = re.sub(r'\s+', ' ', s)
    try:
        import unicodedata
        s_norm = ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')
    except Exception:
        s_norm = s
    return s_norm.title()

def similar_score(a,b):
    if not a or not b: return 0.0
    return fuzz.token_sort_ratio(a, b)/100.0

def guess_columns(df):
    cols = {c.lower(): c for c in df.columns}
    mapping = {}
    for key in ['nome completo','nome','full name','name']:
        if key in cols:
            mapping['full_name'] = cols[key]; break
    for key in ['telefone','telemovel','phone','contact']:
        if key in cols:
            mapping['phone'] = cols[key]; break
    for key in ['nº cap','nr cap','num cap','cap','n cap']:
        if key in cols:
            mapping['cap'] = cols[key]; break
    for key in ['provincia','province']:
        if key in cols:
            mapping['province'] = cols[key]; break
    for key in ['municipio','municipality','city']:
        if key in cols:
            mapping['municipality'] = cols[key]; break
    for key in ['comuna','commune']:
        if key in cols:
            mapping['commune'] = cols[key]; break
    return mapping

if 'df' not in st.session_state:
    st.session_state.df = pd.DataFrame()
if 'locations' not in st.session_state:
    st.session_state.locations = {'provinces':[], 'municipalities':[], 'communes':[]}
if 'dupes' not in st.session_state:
    st.session_state.dupes = {}

st.title("Militantes Manager — Web (Protótipo)")
st.markdown("Ferramenta para importar, detectar duplicados e exportar registos de militantes por CAP.")

with st.sidebar:
    st.header("Upload / Configurações")
    uploaded = st.file_uploader("Subir ficheiro Excel (.xlsx) ou CSV", type=['xlsx','xls','csv'])
    docx_file = st.file_uploader("Subir .docx (opcional)", type=['docx'])
    paste_text = st.text_area("Colar CSV/TSV aqui (opcional)")
    name_threshold = st.slider("Fuzzy name threshold", 50, 99, 88)
    actions = st.radio("Ação", ["Importar e Processar", "Detectar Duplicados", "Marcar e Mostrar", "Exportar Limpo", "Exportar Relatório"])

def import_excel_bytes(bts):
    xls = pd.ExcelFile(io.BytesIO(bts.read()))
    records = []
    for sheet in xls.sheet_names:
        df = xls.parse(sheet, dtype=str)
        mapping = guess_columns(df)
        for _, row in df.iterrows():
            full=""; first=""; last=""
            if 'full_name' in mapping and pd.notna(row.get(mapping['full_name'], "")):
                full = normalize_name(row.get(mapping['full_name'], ""))
                parts = full.split(' ')
                if len(parts)>=2:
                    first, last = parts[0], parts[-1]
                elif len(parts)==1:
                    first = parts[0]
            else:
                if 'first_name' in mapping:
                    first = normalize_name(row.get(mapping['first_name'], ""))
                if 'last_name' in mapping:
                    last = normalize_name(row.get(mapping['last_name'], ""))
                full = f\"{first} {last}\".strip()
            phone = normalize_phone(row.get(mapping.get('phone',''), "")) if mapping.get('phone') else ""
            cap = str(row.get(mapping.get('cap',''), sheet)).strip() if mapping.get('cap') else str(sheet).strip()
            province = row.get(mapping.get('province',''), "")
            municipality = row.get(mapping.get('municipality',''), "")
            commune = row.get(mapping.get('commune',''), "")
            records.append({'sheet':sheet,'full_name':full,'first_name':first,'last_name':last,'phone':phone,'cap':cap,'province':province,'municipality':municipality,'commune':commune})
    return pd.DataFrame(records)

def import_docx_bytes(bts):
    from docx import Document
    doc = Document(io.BytesIO(bts.read()))
    records = []
    for table in doc.tables:
        headers = [c.text.strip() for c in table.rows[0].cells]
        for row in table.rows[1:]:
            vals = [c.text.strip() for c in row.cells]
            rec = dict(zip(headers, vals))
            records.append(rec)
    if not records:
        for p in doc.paragraphs:
            txt = p.text.strip()
            if not txt: continue
            parts = re.split(r'[,;\t]', txt)
            if len(parts)>=2:
                records.append({'full_name':parts[0].strip(), 'phone':parts[1].strip()})
    return pd.DataFrame(records)

def import_from_paste(text):
    try:
        df = pd.read_csv(io.StringIO(text), sep=None, engine='python', dtype=str)
    except Exception:
        df = pd.read_csv(io.StringIO(text), sep='\\t', dtype=str)
    return df

def consolidate_df(existing, newdf):
    df = newdf.copy()
    cols = {c.lower():c for c in df.columns}
    ren={}
    for k in ['nome completo','nome','full name','name']:
        if k in cols: ren[cols[k]]='full_name'; break
    for k in ['telefone','telemovel','phone','contact']:
        if k in cols: ren[cols[k]]='phone'; break
    for k in ['nº cap','nr cap','num cap','cap','n cap']:
        if k in cols: ren[cols[k]]='cap'; break
    for k in ['provincia','province']:
        if k in cols: ren[cols[k]]='province'; break
    for k in ['municipio','municipality','city']:
        if k in cols: ren[cols[k]]='municipality'; break
    for k in ['comuna','commune']:
        if k in cols: ren[cols[k]]='commune'; break
    df.rename(columns=ren, inplace=True)
    for c in ['full_name','first_name','last_name','phone','cap','province','municipality','commune']:
        if c not in df.columns: df[c]=""
    records=[]
    for _, row in df.iterrows():
        full = normalize_name(row.get('full_name',''))
        if full:
            parts = full.split(' '); first=parts[0]; last=parts[-1] if len(parts)>1 else ''
        else:
            first = normalize_name(row.get('first_name','')); last = normalize_name(row.get('last_name',''))
            full = f\"{first} {last}\".strip()
        phone = normalize_phone(row.get('phone',''))
        cap = str(row.get('cap','')).strip()
        province = row.get('province','')
        municipality = row.get('municipality','')
        commune = row.get('commune','')
        records.append({'sheet':cap,'full_name':full,'first_name':first,'last_name':last,'phone':phone,'cap':cap,'province':province,'municipality':municipality,'commune':commune})
    df_parsed = pd.DataFrame(records)
    if existing is None or existing.empty:
        out = df_parsed.reset_index(drop=True)
    else:
        out = pd.concat([existing, df_parsed], ignore_index=True).reset_index(drop=True)
    out['full_name_norm'] = out['full_name'].str.upper().str.replace(r'[^A-Z0-9\\s]','',regex=True).str.strip()
    out['phone_norm'] = out['phone'].astype(str).str.lstrip('0')
    return out

if actions == "Importar e Processar":
    if uploaded is not None:
        try:
            df_new = import_excel_bytes(uploaded)
            st.session_state.df = consolidate_df(st.session_state.df, df_new)
            st.success("Excel importado e processado com sucesso.")
        except Exception as e:
            st.error(f"Falha a importar Excel: {e}")
    if docx_file is not None:
        try:
            df_new = import_docx_bytes(docx_file)
            st.session_state.df = consolidate_df(st.session_state.df, df_new)
            st.success("DOCX importado e processado.")
        except Exception as e:
            st.error(f"Falha a importar DOCX: {e}")
    if paste_text:
        try:
            df_new = import_from_paste(paste_text)
            st.session_state.df = consolidate_df(st.session_state.df, df_new)
            st.success("Dados colados e importados.")
        except Exception as e:
            st.error(f"Falha a colar/importar: {e}")

if st.session_state.df is None or st.session_state.df.empty:
    st.info("Nenhum registo importado ainda. Use a barra lateral para subir/colar ficheiros.")
else:
    st.write(f"Total registos: {len(st.session_state.df)}")
    st.dataframe(st.session_state.df.head(200))

if actions == "Detectar Duplicados":
    if st.session_state.df.empty:
        st.warning("Importa dados primeiro.")
    else:
        thr = name_threshold/100.0
        dup_phone = st.session_state.df[st.session_state.df.duplicated('phone_norm', keep=False) & (st.session_state.df['phone_norm']!="")]
        dup_cap = st.session_state.df[st.session_state.df.duplicated('cap', keep=False) & (st.session_state.df['cap']!="")]
        from collections import defaultdict
        buckets = defaultdict(list)
        for idx,row in st.session_state.df.iterrows():
            name = row['full_name_norm']
            if not name: continue
            key = (name[:1], len(name))
            buckets[key].append((idx, name))
        name_dupes = []
        for key, items in buckets.items():
            m = len(items)
            for i in range(m):
                for j in range(i+1, m):
                    idx1, a = items[i]; idx2, b = items[j]
                    sc = similar_score(a,b)
                    if sc >= thr:
                        name_dupes.append({'idx1': idx1, 'idx2': idx2, 'name1': a, 'name2': b, 'similarity': sc})
        df_name_dupes = pd.DataFrame(name_dupes)
        st.session_state.dupes = {'phone':dup_phone, 'cap':dup_cap, 'name':df_name_dupes}
        st.success(f"Deteção completa. Telefone: {len(dup_phone)} linhas duplicadas; CAP: {len(dup_cap)}; Nome fuzzy: {len(df_name_dupes)} pares.")

if actions == "Marcar e Mostrar":
    if st.session_state.df.empty:
        st.warning("Importa dados primeiro.")
    else:
        st.session_state.df['is_dup_phone'] = st.session_state.df.duplicated('phone_norm', keep='first') & (st.session_state.df['phone_norm']!="")
        st.session_state.df['is_dup_cap'] = st.session_state.df.duplicated('cap', keep='first') & (st.session_state.df['cap']!="")
        st.session_state.df['is_dup_name_sim'] = False
        if 'name' in st.session_state.dupes and not st.session_state.dupes['name'].empty:
            for _, row in st.session_state.dupes['name'].iterrows():
                try:
                    st.session_state.df.at[int(row['idx2']), 'is_dup_name_sim'] = True
                except Exception:
                    pass
        st.success("Registos marcados. Mostrando os primeiros 200 registos.")
        st.dataframe(st.session_state.df.head(200))

if actions == "Exportar Limpo":
    if st.session_state.df.empty:
        st.warning("Importa dados primeiro.")
    else:
        towrite = io.BytesIO()
        with pd.ExcelWriter(towrite, engine='openpyxl') as writer:
            st.session_state.df.to_excel(writer, sheet_name='All_Records', index=False)
        towrite.seek(0)
        st.download_button("Download Excel limpo", data=towrite, file_name="Militantes_Cleaned.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

if actions == "Exportar Relatório":
    if st.session_state.dupes == {}:
        st.warning("Deteta duplicados primeiro.")
    else:
        towrite = io.BytesIO()
        with pd.ExcelWriter(towrite, engine='openpyxl') as writer:
            if 'phone' in st.session_state.dupes:
                st.session_state.dupes['phone'].to_excel(writer, sheet_name='Dupes_By_Phone', index=False)
            if 'cap' in st.session_state.dupes:
                st.session_state.dupes['cap'].to_excel(writer, sheet_name='Dupes_By_CAP', index=False)
            if 'name' in st.session_state.dupes:
                st.session_state.dupes['name'].to_excel(writer, sheet_name='Name_Sim_Dupes', index=False)
        towrite.seek(0)
        st.download_button("Download Relatório de Duplicados", data=towrite, file_name="Militantes_Duplicates_Report.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.sidebar.header("Editar listas de locais")
if st.sidebar.button("Carregar listas atuais"):
    st.session_state.locations = st.session_state.locations or {'provinces':[],'municipalities':[],'communes':[]}
if st.sidebar.button("Guardar listas (baixar JSON)"):
    b = io.BytesIO(json.dumps(st.session_state.locations, ensure_ascii=False, indent=2).encode('utf-8'))
    st.sidebar.download_button("Download locations.json", data=b, file_name="locations_lists.json", mime="application/json")

st.sidebar.write(st.session_state.locations)
