
# Arquivo utils.py - funções partilhadas (opcional)
import re, pandas as pd
def normalize_phone(p):
    if pd.isna(p) or p is None:
        return ""
    s = re.sub(r'[^0-9]', '', str(p))
    return s.lstrip('0')
